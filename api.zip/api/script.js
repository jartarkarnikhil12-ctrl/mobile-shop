// Mobile Shop - API Integration

// API Configuration
const API_BASE_URL = 'https://dummyjson.com';
const PRODUCTS_PER_PAGE = 8;

// State Management
let allProducts = [];
let filteredProducts = [];
let currentPage = 1;
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// DOM Elements
const productsGrid = document.getElementById('productsGrid');
const categoriesGrid = document.getElementById('categoriesGrid');
const dealsGrid = document.getElementById('dealsGrid');
const loadingSpinner = document.getElementById('loadingSpinner');
const loadMoreBtn = document.getElementById('loadMoreBtn');
const loadMoreContainer = document.getElementById('loadMoreContainer');
const searchInput = document.getElementById('searchInput');
const searchBtn = document.getElementById('searchBtn');
const sortSelect = document.getElementById('sortSelect');
const cartItems = document.getElementById('cartItems');
const cartSubtotal = document.getElementById('cartSubtotal');
const cartTotal = document.getElementById('cartTotal');
const cartCount = document.querySelector('.cart-count');
const checkoutBtn = document.getElementById('checkoutBtn');

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    loadProducts();
    loadCategories();
    setupEventListeners();
    updateCartUI();
    
    // Set up smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            }
        });
    });
});

// Set up event listeners
function setupEventListeners() {
    // Search functionality
    searchBtn.addEventListener('click', handleSearch);
    searchInput.addEventListener('keyup', function(e) {
        if (e.key === 'Enter') handleSearch();
    });
    
    // Sort functionality
    sortSelect.addEventListener('change', handleSort);
    
    // Load more products
    loadMoreBtn.addEventListener('click', loadMoreProducts);
    
    // Checkout button
    checkoutBtn.addEventListener('click', handleCheckout);
}

// Load products from API
async function loadProducts() {
    try {
        loadingSpinner.style.display = 'block';
        
        const response = await fetch(`${API_BASE_URL}/products?limit=100`);
        const data = await response.json();
        
        allProducts = data.products;
        filteredProducts = [...allProducts];
        
        displayProducts();
        loadDeals();
    } catch (error) {
        console.error('Error loading products:', error);
        productsGrid.innerHTML = `
            <div class="col-12 text-center py-5">
                <i class="bi bi-exclamation-triangle fs-1 text-danger"></i>
                <h3 class="mt-3">Failed to load products</h3>
                <p>Please check your internet connection and try again.</p>
                <button class="btn btn-primary mt-3" onclick="loadProducts()">Retry</button>
            </div>
        `;
    } finally {
        loadingSpinner.style.display = 'none';
    }
}

// Load categories from API
async function loadCategories() {
    try {
        const response = await fetch(`${API_BASE_URL}/products/categories`);
        const categories = await response.json();
        
        // Filter to get only relevant categories for mobiles
        const mobileCategories = ['smartphones', 'laptops', 'tablets', 'accessories'];
        const filteredCategories = categories.filter(cat => mobileCategories.includes(cat));
        
        displayCategories(filteredCategories);
    } catch (error) {
        console.error('Error loading categories:', error);
    }
}

// Load deals (discounted products)
function loadDeals() {
    // Get products with discount > 15%
    const deals = allProducts
        .filter(product => product.discountPercentage > 15)
        .slice(0, 4);
    
    displayDeals(deals);
}

// Display products in grid
function displayProducts() {
    const startIndex = (currentPage - 1) * PRODUCTS_PER_PAGE;
    const endIndex = startIndex + PRODUCTS_PER_PAGE;
    const productsToShow = filteredProducts.slice(startIndex, endIndex);
    
    // Hide load more button if no more products
    if (filteredProducts.length <= endIndex) {
        loadMoreContainer.style.display = 'none';
    } else {
        loadMoreContainer.style.display = 'block';
    }
    
    if (currentPage === 1) {
        productsGrid.innerHTML = '';
    }
    
    if (productsToShow.length === 0) {
        productsGrid.innerHTML = `
            <div class="col-12 text-center py-5">
                <i class="bi bi-search fs-1 text-muted"></i>
                <h3 class="mt-3">No products found</h3>
                <p>Try adjusting your search or filter to find what you're looking for.</p>
            </div>
        `;
        return;
    }
    
    productsToShow.forEach(product => {
        const productCard = createProductCard(product);
        productsGrid.appendChild(productCard);
    });
    
    // Add fade-in animation to new products
    const newCards = productsGrid.querySelectorAll('.product-card');
    newCards.forEach(card => {
        card.classList.add('fade-in');
    });
}

// Create product card element
function createProductCard(product) {
    const col = document.createElement('div');
    col.className = 'col-lg-3 col-md-4 col-sm-6';
    
    const discount = product.discountPercentage ? Math.round(product.discountPercentage) : 0;
    const discountedPrice = discount > 0 
        ? (product.price * (1 - discount/100)).toFixed(2) 
        : product.price;
    
    col.innerHTML = `
        <div class="card product-card shadow-sm h-100">
            <div class="product-image position-relative">
                <img src="${product.thumbnail}" alt="${product.title}" class="img-fluid">
                ${discount > 0 ? `<span class="deal-badge">${discount}% OFF</span>` : ''}
            </div>
            <div class="card-body d-flex flex-column">
                <h5 class="product-title">${product.title}</h5>
                <p class="product-description">${product.description}</p>
                
                <div class="mt-auto">
                    <div class="product-rating">
                        ${generateStarRating(product.rating)}
                        <span class="ms-1">(${product.rating})</span>
                    </div>
                    
                    <div class="product-stock ${product.stock > 0 ? 'in-stock' : 'out-of-stock'}">
                        ${product.stock > 0 ? 'In Stock' : 'Out of Stock'}
                    </div>
                    
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="product-price">$${discountedPrice}</div>
                            ${discount > 0 ? `<small class="text-muted"><del>$${product.price}</del></small>` : ''}
                        </div>
                        <div class="btn-group">
                            <button class="btn btn-sm btn-outline-primary view-details" data-id="${product.id}">
                                <i class="bi bi-eye"></i>
                            </button>
                            <button class="btn btn-sm btn-primary add-to-cart" data-id="${product.id}" 
                                    ${product.stock <= 0 ? 'disabled' : ''}>
                                <i class="bi bi-cart-plus"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Add event listeners to buttons
    col.querySelector('.view-details').addEventListener('click', () => showProductDetails(product.id));
    col.querySelector('.add-to-cart').addEventListener('click', () => addToCart(product));
    
    return col;
}

// Generate star rating HTML
function generateStarRating(rating) {
    let stars = '';
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    for (let i = 1; i <= 5; i++) {
        if (i <= fullStars) {
            stars += '<i class="bi bi-star-fill"></i>';
        } else if (i === fullStars + 1 && hasHalfStar) {
            stars += '<i class="bi bi-star-half"></i>';
        } else {
            stars += '<i class="bi bi-star"></i>';
        }
    }
    
    return stars;
}

// Display categories
function displayCategories(categories) {
    categoriesGrid.innerHTML = '';
    
    const categoryImages = {
        'smartphones': 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
        'laptops': 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?ixlib=rb-4.0.3&auto=format&fit=crop&w-800&q=80',
        'tablets': 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
        'accessories': 'https://images.unsplash.com/photo-1586950012036-b957f2c7cbf3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
    };
    
    categories.forEach(category => {
        const col = document.createElement('div');
        col.className = 'col-lg-3 col-md-6';
        
        col.innerHTML = `
            <div class="category-card shadow-sm">
                <div class="category-image">
                    <img src="${categoryImages[category] || 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'}" 
                         alt="${category}">
                </div>
                <h4 class="category-title">${formatCategoryName(category)}</h4>
            </div>
        `;
        
        col.addEventListener('click', () => filterByCategory(category));
        categoriesGrid.appendChild(col);
    });
}

// Format category name for display
function formatCategoryName(category) {
    return category.charAt(0).toUpperCase() + category.slice(1);
}

// Display deals
function displayDeals(deals) {
    dealsGrid.innerHTML = '';
    
    deals.forEach(product => {
        const col = document.createElement('div');
        col.className = 'col-lg-3 col-md-6';
        
        const discount = Math.round(product.discountPercentage);
        const discountedPrice = (product.price * (1 - discount/100)).toFixed(2);
        
        col.innerHTML = `
            <div class="card product-card shadow-sm h-100">
                <div class="product-image position-relative">
                    <img src="${product.thumbnail}" alt="${product.title}" class="img-fluid">
                    <span class="deal-badge">${discount}% OFF</span>
                </div>
                <div class="card-body d-flex flex-column">
                    <h5 class="product-title">${product.title}</h5>
                    <div class="mt-auto">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="product-price">$${discountedPrice}</div>
                                <small class="text-muted"><del>$${product.price}</del></small>
                            </div>
                            <button class="btn btn-sm btn-primary add-to-cart" data-id="${product.id}">
                                <i class="bi bi-cart-plus"></i> Add
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        col.querySelector('.add-to-cart').addEventListener('click', () => addToCart(product));
        dealsGrid.appendChild(col);
    });
}

// Handle search
function handleSearch() {
    const searchTerm = searchInput.value.trim().toLowerCase();
    
    if (searchTerm === '') {
        filteredProducts = [...allProducts];
    } else {
        filteredProducts = allProducts.filter(product => 
            product.title.toLowerCase().includes(searchTerm) ||
            product.description.toLowerCase().includes(searchTerm) ||
            product.brand.toLowerCase().includes(searchTerm) ||
            product.category.toLowerCase().includes(searchTerm)
        );
    }
    
    currentPage = 1;
    displayProducts();
}

// Handle sort
function handleSort() {
    const sortValue = sortSelect.value;
    
    switch(sortValue) {
        case 'price-low':
            filteredProducts.sort((a, b) => a.price - b.price);
            break;
        case 'price-high':
            filteredProducts.sort((a, b) => b.price - a.price);
            break;
        case 'rating':
            filteredProducts.sort((a, b) => b.rating - a.rating);
            break;
        default:
            filteredProducts.sort((a, b) => a.id - b.id);
    }
    
    currentPage = 1;
    displayProducts();
}

// Filter by category
function filterByCategory(category) {
    filteredProducts = allProducts.filter(product => 
        product.category === category
    );
    
    currentPage = 1;
    displayProducts();
    
    // Scroll to products section
    document.getElementById('products').scrollIntoView({ behavior: 'smooth' });
}

// Load more products
function loadMoreProducts() {
    currentPage++;
    displayProducts();
}

// Show product details modal
async function showProductDetails(productId) {
    try {
        const response = await fetch(`${API_BASE_URL}/products/${productId}`);
        const product = await response.json();
        
        const discount = product.discountPercentage ? Math.round(product.discountPercentage) : 0;
        const discountedPrice = discount > 0 
            ? (product.price * (1 - discount/100)).toFixed(2) 
            : product.price;
        
        const modalBody = document.getElementById('productModalBody');
        modalBody.innerHTML = `
            <div class="row">
                <div class="col-md-6">
                    <img src="${product.thumbnail}" alt="${product.title}" 
                         class="img-fluid rounded product-details-image">
                    ${product.images && product.images.length > 0 ? `
                        <div class="d-flex mt-3">
                            ${product.images.slice(0, 3).map(img => `
                                <img src="${img}" class="img-thumbnail me-2" style="width: 80px; height: 80px; object-fit: cover;">
                            `).join('')}
                        </div>
                    ` : ''}
                </div>
                <div class="col-md-6">
                    <h3>${product.title}</h3>
                    <div class="product-rating mb-3">
                        ${generateStarRating(product.rating)}
                        <span class="ms-2">${product.rating} (${product.reviews || 0} reviews)</span>
                    </div>
                    
                    <div class="mb-3">
                        <h4 class="text-primary">$${discountedPrice}</h4>
                        ${discount > 0 ? `
                            <div>
                                <span class="text-muted"><del>$${product.price}</del></span>
                                <span class="badge bg-danger ms-2">${discount}% OFF</span>
                            </div>
                        ` : ''}
                    </div>
                    
                    <div class="mb-4">
                        <h5>Description</h5>
                        <p>${product.description}</p>
                        
                        <div class="row mt-3">
                            <div class="col-6">
                                <p><strong>Brand:</strong> ${product.brand}</p>
                                <p><strong>Category:</strong> ${formatCategoryName(product.category)}</p>
                            </div>
                            <div class="col-6">
                                <p><strong>Stock:</strong> <span class="${product.stock > 0 ? 'text-success' : 'text-danger'}">
                                    ${product.stock} units available
                                </span></p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="d-flex">
                        <button class="btn btn-primary btn-lg flex-grow-1 me-2 add-to-cart-modal" data-id="${product.id}">
                            <i class="bi bi-cart-plus"></i> Add to Cart
                        </button>
                        <button class="btn btn-outline-primary btn-lg">
                            <i class="bi bi-heart"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        // Add event listener to modal add to cart button
        modalBody.querySelector('.add-to-cart-modal').addEventListener('click', () => {
            addToCart(product);
            // Close modal after adding to cart
            const modal = bootstrap.Modal.getInstance(document.getElementById('productModal'));
            modal.hide();
        });
        
        // Update modal title
        document.getElementById('productModalTitle').textContent = product.title;
        
        // Show modal
        const productModal = new bootstrap.Modal(document.getElementById('productModal'));
        productModal.show();
    } catch (error) {
        console.error('Error loading product details:', error);
        alert('Failed to load product details. Please try again.');
    }
}

// Cart Functions
function addToCart(product) {
    // Check if product is already in cart
    const existingItem = cart.find(item => item.id === product.id);
    
    if (existingItem) {
        // Increase quantity if already in cart
        existingItem.quantity += 1;
    } else {
        // Add new item to cart
        const discount = product.discountPercentage ? Math.round(product.discountPercentage) : 0;
        const price = discount > 0 
            ? (product.price * (1 - discount/100)).toFixed(2) 
            : product.price;
            
        cart.push({
            id: product.id,
            title: product.title,
            price: parseFloat(price),
            thumbnail: product.thumbnail,
            quantity: 1,
            stock: product.stock
        });
    }
    
    // Save to localStorage
    localStorage.setItem('cart', JSON.stringify(cart));
    
    // Update UI
    updateCartUI();
    
    // Show success message
    showToast(`${product.title} added to cart!`, 'success');
}

function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartUI();
    showToast('Item removed from cart', 'info');
}

function updateCartQuantity(productId, newQuantity) {
    if (newQuantity < 1) {
        removeFromCart(productId);
        return;
    }
    
    const item = cart.find(item => item.id === productId);
    if (item) {
        // Check if quantity exceeds stock
        if (newQuantity > item.stock) {
            showToast(`Only ${item.stock} units available in stock`, 'warning');
            newQuantity = item.stock;
        }
        
        item.quantity = newQuantity;
        localStorage.setItem('cart', JSON.stringify(cart));
        updateCartUI();
    }
}

function updateCartUI() {
    // Update cart count in navbar
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCount.textContent = totalItems;
    
    // Update cart modal
    updateCartModal();
}

function updateCartModal() {
    if (cart.length === 0) {
        cartItems.innerHTML = '<p class="text-center py-4">Your cart is empty</p>';
        cartSubtotal.textContent = '$0.00';
        cartTotal.textContent = '$0.00';
        return;
    }
    
    // Calculate subtotal
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const shipping = subtotal > 500 ? 0 : 10;
    const total = subtotal + shipping;
    
    // Update cart items
    cartItems.innerHTML = cart.map(item => `
        <div class="cart-item d-flex align-items-center">
            <div class="flex-shrink-0">
                <img src="${item.thumbnail}" alt="${item.title}" class="cart-item-image rounded">
            </div>
            <div class="flex-grow-1 ms-3">
                <h6 class="mb-1">${item.title}</h6>
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-primary fw-bold">$${item.price.toFixed(2)}</span>
                        <div class="input-group input-group-sm mt-2 cart-item-quantity">
                            <button class="btn btn-outline-secondary decrease-quantity" data-id="${item.id}">-</button>
                            <input type="text" class="form-control text-center" value="${item.quantity}" readonly>
                            <button class="btn btn-outline-secondary increase-quantity" data-id="${item.id}">+</button>
                        </div>
                    </div>
                    <div>
                        <span class="fw-bold">$${(item.price * item.quantity).toFixed(2)}</span>
                        <button class="btn btn-link text-danger remove-item" data-id="${item.id}">
                            <i class="bi bi-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `).join('');
    
    // Add event listeners to cart buttons
    cartItems.querySelectorAll('.decrease-quantity').forEach(btn => {
        btn.addEventListener('click', function() {
            const productId = parseInt(this.getAttribute('data-id'));
            const item = cart.find(item => item.id === productId);
            if (item) {
                updateCartQuantity(productId, item.quantity - 1);
            }
        });
    });
    
    cartItems.querySelectorAll('.increase-quantity').forEach(btn => {
        btn.addEventListener('click', function() {
            const productId = parseInt(this.getAttribute('data-id'));
            const item = cart.find(item => item.id === productId);
            if (item) {
                updateCartQuantity(productId, item.quantity + 1);
            }
        });
    });
    
    cartItems.querySelectorAll('.remove-item').forEach(btn => {
        btn.addEventListener('click', function() {
            const productId = parseInt(this.getAttribute('data-id'));
            removeFromCart(productId);
        });
    });
    
    // Update totals
    cartSubtotal.textContent = `$${subtotal.toFixed(2)}`;
    document.getElementById('cartShipping').textContent = shipping === 0 ? 'FREE' : `$${shipping.toFixed(2)}`;
    cartTotal.textContent = `$${total.toFixed(2)}`;
}

function handleCheckout() {
    if (cart.length === 0) {
        showToast('Your cart is empty', 'warning');
        return;
    }
    
    const modal = bootstrap.Modal.getInstance(document.getElementById('cartModal'));
    modal.hide();
    
    showToast('Checkout functionality would be implemented here!', 'info');
    
    // In a real application, you would redirect to a checkout page
    // or show a checkout form
}

// Toast notification
function showToast(message, type = 'info') {
    // Create toast container if it doesn't exist
    let toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        document.body.appendChild(toastContainer);
    }
    
    const toastId = 'toast-' + Date.now();
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-bg-${type} border-0`;
    toast.id = toastId;
    toast.setAttribute('role', 'alert');
    
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    
    toastContainer.appendChild(toast);
    
    // Show toast
    const bsToast = new bootstrap.Toast(toast, { delay: 3000 });
    bsToast.show();
    
    // Remove toast after it's hidden
    toast.addEventListener('hidden.bs.toast', function() {
        toast.remove();
    });
}